package com.qsxh.entity;

public class ImageReturn {

    private int isok;
    private String imgBase ;
    private String imgFormat;
    private String lookIndex;
    private String result;
    private String file;
    private String imgurl;
    private String userid;
    private String photoid;

    public int getIsok() {
        return isok;
    }

    public void setIsok(int isok) {
        this.isok = isok;
    }

    public String getImgBase() {
        return imgBase;
    }

    public void setImgBase(String imgBase) {
        this.imgBase = imgBase;
    }

    public String getImgFormat() {
        return imgFormat;
    }

    public void setImgFormat(String imgFormat) {
        this.imgFormat = imgFormat;
    }

    public String getLookIndex() {
        return lookIndex;
    }

    public void setLookIndex(String lookIndex) {
        this.lookIndex = lookIndex;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getFile() {
        return file;
    }

    public void setFile(String file) {
        this.file = file;
    }

    public String getImgurl() {
        return imgurl;
    }

    public void setImgurl(String imgurl) {
        this.imgurl = imgurl;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getPhotoid() {
        return photoid;
    }

    public void setPhotoid(String photoid) {
        this.photoid = photoid;
    }
}
