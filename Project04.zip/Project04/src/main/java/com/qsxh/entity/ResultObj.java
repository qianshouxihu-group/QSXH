package com.qsxh.entity;

public class ResultObj {
    private String msg;

    public ResultObj() {
    }

    public ResultObj(String msg) {
        this.msg = msg;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
