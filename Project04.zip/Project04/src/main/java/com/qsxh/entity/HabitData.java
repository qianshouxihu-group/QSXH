package com.qsxh.entity;

public class HabitData {

    private Integer habitid;
    private String userid;
    private String hid;
    private String hname;
    private String tyid;
    private String tyname;

    public HabitData() {
    }

    public Integer getHabitid() {
        return habitid;
    }

    public void setHabitid(Integer habitid) {
        this.habitid = habitid;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getHid() {
        return hid;
    }

    public void setHid(String hid) {
        this.hid = hid;
    }

    public String getHname() {
        return hname;
    }

    public void setHname(String hname) {
        this.hname = hname;
    }

    public String getTyid() {
        return tyid;
    }

    public void setTyid(String tyid) {
        this.tyid = tyid;
    }

    public String getTyname() {
        return tyname;
    }

    public void setTyname(String tyname) {
        this.tyname = tyname;
    }
}
