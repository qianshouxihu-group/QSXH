package com.qsxh.service;

import com.qsxh.entity.Dating;

public interface IDatingBiz {

    //和TA约会
    public String dating(Dating dating);
}
